package packages;

public interface Carres {

    public float getAire(float cote);
    public float getPerimetre(float cote);
}
