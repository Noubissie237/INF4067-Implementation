package packages;

/* Pour les différents types de fichier */
public enum Type {
    TXT,
    PDF,
    DOSSIER
}
